#'1st program'
print((9**0.5)*5)
#'2nd program'
print((9.99>9.95 and 1000 != 1000.1))
#'3rd program'
print(1234%1000) , print((234//10))
print((5678%1000)) , print((678//10))
print((23+67))
#'4st program'
print(13.42//1) , print(int(13.0))
print(42.13*100), print(int(4213.0)) , print((4213%100))
print((42.13//1)) , print(int(42.0))
print((13.42*100)) , print(int(1342.0)) , print(1342%100)
print((13==13)) and print((42==42))